# 🎁 Bot de Codiguinhos da Guize City

Bot para Discord que gerencia o resgate de codiguinhos com entrega automática de cargo.

## ✨ Funcionalidades

- 🎟️ **Painel visual** com botão de resgate
- 📝 **Modal (pop-up)** para digitar o codiguinho
- 🔑 **Validação case-insensitive** (aceita `guize`, `GUIZE`, `Guize`, `gUiZe`, etc.)
- 🎭 **Entrega automática de cargo** no Discord
- 🚫 **Um resgate por jogador** — bloqueia novas tentativas após o primeiro resgate
- 💾 **Banco de dados JSON** — os resgates não se perdem ao reiniciar o bot
- 🎨 **Identidade visual azul e preto** da Guize City

## 📦 Instalação

### 1. Pré-requisitos

- [Node.js](https://nodejs.org/) versão 18 ou superior

### 2. Instalar dependências

```bash
npm install
```

### 3. Configurar o bot

Copie o arquivo `.env.example` para `.env` e preencha com seus dados:

```bash
copy .env.example .env
```

Edite o `.env`:

```
DISCORD_TOKEN=token_do_seu_bot
CLIENT_ID=id_da_aplicacao
GUILD_ID=id_do_seu_servidor
```

- **DISCORD_TOKEN**: Token do bot (Discord Developer Portal → sua aplicação → Bot → Reset Token)
- **CLIENT_ID**: ID da aplicação (Discord Developer Portal → sua aplicação → General Information → App ID)
- **GUILD_ID**: ID do servidor onde o bot vai funcionar (opcional, mas recomendado para registro rápido de comandos)

### 4. Registrar os comandos

```bash
npm run deploy
```

### 5. Iniciar o bot

```bash
npm start
```

## 🎮 Como usar

### Comando `/panel`
1. Com o bot online e no servidor, digite `/panel` no canal desejado
2. O painel aparecerá com o botão **🎁 RESGATAR CODIGUINHO**
3. O jogador clica no botão, digita o codiguinho e confirma
4. Se o código for válido, o cargo é entregue automaticamente

### Comando `/codiguin` (restrito)
1. Digite `/codiguin` no canal desejado
2. Apenas membros com o cargo autorizado (`staffRoleId` na config) podem usar
3. Envia o mesmo painel com o botão de resgate
4. Se o usuário não tiver o cargo, recebe uma mensagem de acesso negado

## 🔑 Codiguinhos válidos

| Código  |
|---------|
| GUIZE   |
| GUI     |
| AILLA   |
| DOG     |
| KELVEN  |

Para adicionar ou alterar os códigos, edite o arquivo `config/config.json`.

## ⚙️ Configuração

Edite `config/config.json` para alterar:

- `roleId` — ID do cargo entregue aos jogadores
- `staffRoleId` — ID do cargo autorizado a usar o comando `/codiguin`
- `validCodes` — lista de codiguinhos válidos
- `panelTitle` — título do painel
- `embedThumbnail` / `embedImage` — URL de imagens opcionais nos embeds
- `footerText` — texto do rodapé dos embeds

## 🔧 Permissões do bot

No servidor, o bot precisa das seguintes permissões:

- **Ver canais, mensagens e enviar mensagens** — para responder comandos
- **Gerenciar Cargos** — para entregar o cargo aos jogadores
- **Usar comandos de aplicativo** — para os comandos slash

> ⚠️ O cargo entregue (`1504864301545160786`) deve estar **abaixo** do cargo mais alto do bot na hierarquia de cargos do servidor.

## 📁 Estrutura do projeto

```
bot codiguinho guize/
├── package.json              # Dependências e scripts
├── .env.example              # Template de variáveis de ambiente
├── .gitignore
├── config/
│   └── config.json           # Configuração (cargo, códigos, cores)
├── data/
│   └── codiguinhos.json    # Banco de dados JSON (criado automaticamente)
└── src/
    ├── index.js              # Arquivo principal — inicia o bot
    ├── database.js           # Gerenciador do banco de dados (JSON)
    ├── deploy-commands.js    # Registro de comandos slash
    ├── commands/
    │   ├── panel.js          # Comando /panel (público)
    │   └── codiguin.js       # Comando /codiguin (restrito ao cargo staff)
    ├── events/
    │   ├── ready.js          # Evento de conexão
    │   └── interactionCreate.js  # Direciona interações
    ├── handlers/
    │   ├── buttonHandler.js  # Processa clique no botão
    │   └── modalHandler.js   # Processa resgate no modal
    └── utils/
        ├── codes.js          # Validação de codiguinhos
        └── embeds.js         # Construtores de embeds
```
