/**
 * ============================================
 * Registro de Comandos Slash
 * ============================================
 * Registra os comandos do bot no Discord.
 *
 * Uso:  node src/deploy-commands.js
 * Ou:   npm run deploy
 *
 * Se GUILD_ID estiver definido no .env, os
 * comandos são registrados apenas naquele
 * servidor (instantâneo). Caso contrário,
 * são registrados globalmente (pode demorar
 * até 1 hora para aparecer).
 * ============================================
 */

require("dotenv").config();
const { REST, Routes } = require("discord.js");
const fs = require("fs");
const path = require("path");

// Verifica as variáveis necessárias
if (!process.env.DISCORD_TOKEN) {
  console.error("❌ DISCORD_TOKEN não encontrado no .env");
  process.exit(1);
}
if (!process.env.CLIENT_ID) {
  console.error("❌ CLIENT_ID não encontrado no .env");
  process.exit(1);
}

// Coleta os dados dos comandos
const commands = [];
const commandsPath = path.join(__dirname, "commands");
const commandFiles = fs.readdirSync(commandsPath).filter((f) => f.endsWith(".js"));

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  if ("data" in command) {
    commands.push(command.data.toJSON());
  }
}

const rest = new REST().setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log(`⏳ Registrando ${commands.length} comando(s)...`);

    if (process.env.GUILD_ID) {
      // Registro no servidor (instantâneo)
      await rest.put(
        Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
        { body: commands }
      );
      console.log("✅ Comandos registrados no servidor!");
    } else {
      // Registro global (pode demorar até 1h)
      await rest.put(
        Routes.applicationCommands(process.env.CLIENT_ID),
        { body: commands }
      );
      console.log("✅ Comandos registrados globalmente!");
    }
  } catch (error) {
    console.error("❌ Erro ao registrar comandos:", error);
  }
})();
