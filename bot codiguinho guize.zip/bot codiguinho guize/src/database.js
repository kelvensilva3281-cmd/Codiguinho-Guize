/**
 * ============================================
 * Gerenciador de Banco de Dados (JSON)
 * ============================================
 * Salva todos os resgates de codiguinhos em um
 * arquivo JSON para que as informações não sejam
 * perdidas ao reiniciar o bot.
 *
 * Usa armazenamento em arquivo JSON puro em
 * JavaScript — não requer compilação nativa.
 * ============================================
 */

const fs = require("fs");
const path = require("path");

// Garante que a pasta "data" exista
const dataDir = path.join(__dirname, "..", "data");
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, "codiguinhos.json");

/**
 * Lê o banco de dados do arquivo JSON.
 * @returns {{ redemptions: Array }} Os dados do banco.
 */
function readDB() {
  try {
    if (!fs.existsSync(dbPath)) {
      return { redemptions: [] };
    }
    const raw = fs.readFileSync(dbPath, "utf8");
    return JSON.parse(raw);
  } catch (error) {
    console.error("Erro ao ler o banco de dados:", error);
    return { redemptions: [] };
  }
}

/**
 * Escreve o banco de dados no arquivo JSON.
 * @param {{ redemptions: Array }} data Os dados a salvar.
 */
function writeDB(data) {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2), "utf8");
  } catch (error) {
    console.error("Erro ao salvar o banco de dados:", error);
  }
}

/**
 * Busca o resgate de um jogador pelo ID.
 * @param {string} userId O ID do Discord do jogador.
 * @returns {object|null} O registro do resgate ou null.
 */
function getRedemption(userId) {
  const data = readDB();
  return data.redemptions.find((r) => r.user_id === userId) || null;
}

/**
 * Adiciona um novo resgate ao banco de dados.
 * @param {string} userId O ID do Discord do jogador.
 * @param {string} username O nome do jogador.
 * @param {string} code O codiguinho resgatado.
 * @param {string} redeemedAt A data/hora do resgate (ISO string).
 */
function addRedemption(userId, username, code, redeemedAt) {
  const data = readDB();
  data.redemptions.push({
    user_id: userId,
    username,
    code,
    redeemed_at: redeemedAt,
  });
  writeDB(data);
}

/**
 * Retorna todos os resgates ordenados do mais recente ao mais antigo.
 * @returns {Array} Lista de resgates.
 */
function getAllRedemptions() {
  const data = readDB();
  return [...data.redemptions].sort(
    (a, b) => new Date(b.redeemed_at) - new Date(a.redeemed_at)
  );
}

module.exports = {
  getRedemption,
  addRedemption,
  getAllRedemptions,
};
