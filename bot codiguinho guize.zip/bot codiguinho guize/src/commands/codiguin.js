/**
 * ============================================
 * Comando: /codiguin
 * ============================================
 * Envia o painel de codiguinhos da Guize City.
 * Apenas membros com o cargo autorizado
 * (config.staffRoleId) podem usar este comando.
 * ============================================
 */

const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

const config = require("../../config/config.json");
const { createPanelEmbed, createNoPermissionEmbed } = require("../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("codiguin")
    .setDescription("Envia o painel de codiguinhos (apenas cargo autorizado)"),

  async execute(interaction) {
    // ── Verificar permissão: o usuário precisa ter o cargo staffRoleId ──
    const member = interaction.member;
    const hasRole =
      member && member.roles && member.roles.cache.has(config.staffRoleId);

    if (!hasRole) {
      const embed = createNoPermissionEmbed();
      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    // ── Permissão concedida: enviar o painel ──
    const embed = createPanelEmbed();

    const button = new ButtonBuilder()
      .setCustomId("redeem_codiguinho")
      .setLabel("🎁 RESGATAR CODIGUINHO")
      .setStyle(ButtonStyle.Primary);

    const row = new ActionRowBuilder().addComponents(button);

    await interaction.reply({ embeds: [embed], components: [row] });
  },
};
