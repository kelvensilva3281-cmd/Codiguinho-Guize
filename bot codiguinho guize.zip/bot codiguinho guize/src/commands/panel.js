/**
 * ============================================
 * Comando: /panel
 * ============================================
 * Envia o painel de codiguinhos da Guize City
 * no canal onde o comando foi executado.
 * O painel contém a descrição e o botão de
 * resgate.
 * ============================================
 */

const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

const { createPanelEmbed } = require("../utils/embeds");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("panel")
    .setDescription("Envia o painel de codiguinhos da Guize City"),

  async execute(interaction) {
    const embed = createPanelEmbed();

    // Botão "🎁 RESGATAR CODIGUINHO"
    const button = new ButtonBuilder()
      .setCustomId("redeem_codiguinho")
      .setLabel("🎁 RESGATAR CODIGUINHO")
      .setStyle(ButtonStyle.Primary);

    const row = new ActionRowBuilder().addComponents(button);

    await interaction.reply({ embeds: [embed], components: [row] });
  },
};
