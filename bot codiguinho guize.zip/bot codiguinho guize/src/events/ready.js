/**
 * ============================================
 * Evento: ready
 * ============================================
 * Executado uma única vez quando o bot se
 * conecta ao Discord com sucesso.
 * ============================================
 */

module.exports = {
  name: "ready",
  once: true,
  execute(client) {
    console.log("========================================");
    console.log(`✅ Bot conectado como ${client.user.tag}`);
    console.log("🟦 Guize City • Sistema de Codiguinhos");
    console.log("========================================");
  },
};
