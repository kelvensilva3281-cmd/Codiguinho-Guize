/**
 * ============================================
 * Evento: interactionCreate
 * ============================================
 * Direciona todas as interações (comandos
 * slash, botões e modais) para os handlers
 * correspondentes.
 * ============================================
 */

const { handleButton } = require("../handlers/buttonHandler");
const { handleModal } = require("../handlers/modalHandler");

module.exports = {
  name: "interactionCreate",
  async execute(interaction, client) {
    // Comando slash (/panel)
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;

      try {
        await command.execute(interaction);
      } catch (error) {
        console.error("Erro ao executar comando:", error);
        const reply = {
          content: "❌ Ocorreu um erro ao executar este comando.",
          ephemeral: true,
        };
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(reply).catch(() => {});
        } else {
          await interaction.reply(reply).catch(() => {});
        }
      }
      return;
    }

    // Clique em botão (🎁 RESGATAR CODIGUINHO)
    if (interaction.isButton()) {
      try {
        await handleButton(interaction);
      } catch (error) {
        console.error("Erro no handler de botão:", error);
      }
      return;
    }

    // Submissão de modal (pop-up de resgate)
    if (interaction.isModalSubmit()) {
      try {
        await handleModal(interaction);
      } catch (error) {
        console.error("Erro no handler de modal:", error);
      }
      return;
    }
  },
};
