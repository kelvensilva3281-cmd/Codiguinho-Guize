/**
 * ============================================
 * Bot de Codiguinhos da Guize City
 * ============================================
 * Arquivo principal — inicializa o bot,
 * carrega eventos e comandos.
 * ============================================
 */

require("dotenv").config();
const fs = require("fs");
const path = require("path");
const { Client, GatewayIntentBits, Collection } = require("discord.js");

// Verifica se o token foi configurado
if (!process.env.DISCORD_TOKEN) {
  console.error("❌ DISCORD_TOKEN não encontrado!");
  console.error("   Copie o arquivo .env.example para .env e preencha com seu token.");
  process.exit(1);
}

// Cria o cliente do bot com as intents necessárias
const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers],
});

// ── Carrega os eventos ──
const eventsPath = path.join(__dirname, "events");
const eventFiles = fs.readdirSync(eventsPath).filter((f) => f.endsWith(".js"));

for (const file of eventFiles) {
  const event = require(path.join(eventsPath, file));
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, client));
  } else {
    client.on(event.name, (...args) => event.execute(...args, client));
  }
}

// ── Carrega os comandos slash ──
client.commands = new Collection();
const commandsPath = path.join(__dirname, "commands");
const commandFiles = fs.readdirSync(commandsPath).filter((f) => f.endsWith(".js"));

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  if ("data" in command && "execute" in command) {
    client.commands.set(command.data.name, command);
  } else {
    console.warn(`⚠️ O comando em ${file} está faltando "data" ou "execute".`);
  }
}

// Inicia o bot
client.login(process.env.DISCORD_TOKEN);
