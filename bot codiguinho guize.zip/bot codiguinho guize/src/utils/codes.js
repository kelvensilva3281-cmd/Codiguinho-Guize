/**
 * ============================================
 * Validação de Codiguinhos
 * ============================================
 * Verifica se o código digitado pelo jogador
 * existe na lista de códigos válidos.
 * A comparação é case-insensitive (não
 * diferencia maiúsculas de minúsculas).
 * ============================================
 */

const config = require("../../config/config.json");

// Pré-converte todos os códigos válidos para maiúsculas
const validCodesUpper = config.validCodes.map((c) => c.toUpperCase());

/**
 * Verifica se um código é válido.
 * @param {string} code - O código digitado pelo jogador.
 * @returns {boolean} true se o código existe, false caso contrário.
 */
function isValidCode(code) {
  const normalized = code.trim().toUpperCase();
  return validCodesUpper.includes(normalized);
}

/**
 * Retorna o código normalizado (maiúsculo, sem espaços).
 * @param {string} code - O código digitado pelo jogador.
 * @returns {string} O código normalizado.
 */
function normalizeCode(code) {
  return code.trim().toUpperCase();
}

module.exports = { isValidCode, normalizeCode };
