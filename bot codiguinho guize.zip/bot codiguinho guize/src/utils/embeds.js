/**
 * ============================================
 * Construtores de Embeds
 * ============================================
 * Centraliza a criação de todas as mensagens
 * embed do bot, mantendo a identidade visual
 * da Guize City (azul e preto).
 * ============================================
 */

const { EmbedBuilder } = require("discord.js");

const config = require("../../config/config.json");

// Cor primária da Guize City — azul
const PRIMARY_COLOR = 0x2563eb;

/**
 * Adiciona thumbnail e imagem opcionais ao embed se definidas na config.
 */
function applyOptionalMedia(embed) {
  if (config.embedThumbnail) embed.setThumbnail(config.embedThumbnail);
  if (config.embedImage) embed.setImage(config.embedImage);
  return embed;
}

/**
 * Embed do painel principal de codiguinhos.
 */
function createPanelEmbed() {
  const embed = new EmbedBuilder()
    .setTitle(config.panelTitle)
    .setDescription(
      "**🟦 Bem-vindo ao sistema de Codiguinhos da Guize City!**\n\n" +
        "Resgate seus codiguinhos e receba recompensas exclusivas! 🎁\n\n" +
        "**📌 Como resgatar:**\n" +
        "> Clique no botão **🎁 RESGATAR CODIGUINHO** abaixo\n" +
        "> Digite seu codiguinho no pop-up que aparecer\n" +
        "> Confirme o resgate\n\n" +
        "**⚠️ Atenção:**\n" +
        "> Cada jogador pode resgatar **apenas UM codiguinho** no total.\n" +
        "> Após o primeiro resgate, nenhum outro código poderá ser utilizado."
    )
    .setColor(PRIMARY_COLOR)
    .setFooter({ text: config.footerText })
    .setTimestamp();

  applyOptionalMedia(embed);
  return embed;
}

/**
 * Embed de resgate realizado com sucesso.
 */
function createSuccessEmbed(code, username) {
  return new EmbedBuilder()
    .setTitle("✅ Codiguinho Resgatado com Sucesso!")
    .setDescription(
      `🎉 Parabéns, **${username}**!\n\n` +
        `Você resgatou o codiguinho: \`\`${code}\`\`\n\n` +
        `🎭 O cargo foi entregue automaticamente no servidor!\n\n` +
        "⚠️ **Atenção:** Você não poderá resgatar outro codiguinho.\n" +
        "Cada jogador só pode resgatar **UM** codiguinho no total."
    )
    .setColor(0x22c55e)
    .setFooter({ text: config.footerText })
    .setTimestamp();
}

/**
 * Embed de código inválido.
 */
function createInvalidCodeEmbed() {
  return new EmbedBuilder()
    .setTitle("❌ Codiguinho Inválido")
    .setDescription(
      "🚫 O codiguinho digitado **não existe** ou é inválido.\n\n" +
        "Verifique o código e tente novamente.\n\n" +
        "**Dica:** O sistema não diferencia maiúsculas de minúsculas.\n" +
        "Exemplo: `guize`, `GUIZE` e `Guize` são aceitos."
    )
    .setColor(0xef4444)
    .setFooter({ text: config.footerText })
    .setTimestamp();
}

/**
 * Embed de jogador que já resgatou um codiguinho.
 */
function createAlreadyRedeemedEmbed(code) {
  return new EmbedBuilder()
    .setTitle("🚫 Resgate Bloqueado")
    .setDescription(
      "⚠️ Você **já resgatou** um codiguinho anteriormente!\n\n" +
        `Você utilizou o código: \`\`${code}\`\`\n\n` +
        "Cada jogador só pode resgatar **UM** codiguinho no total.\n" +
        "Não é possível resgatar outro código."
    )
    .setColor(0xf97316)
    .setFooter({ text: config.footerText })
    .setTimestamp();
}

/**
 * Embed de erro ao entregar o cargo.
 */
function createErrorEmbed(message) {
  return new EmbedBuilder()
    .setTitle("❌ Erro")
    .setDescription(message)
    .setColor(0xef4444)
    .setFooter({ text: config.footerText })
    .setTimestamp();
}

/**
 * Embed de permissão negada.
 */
function createNoPermissionEmbed() {
  return new EmbedBuilder()
    .setTitle("🚫 Acesso Negado")
    .setDescription(
      "Você **não tem permissão** para usar este comando.\n\n" +
        "Apenas membros com o cargo autorizado podem utilizar o `/codiguin`."
    )
    .setColor(0xef4444)
    .setFooter({ text: config.footerText })
    .setTimestamp();
}

module.exports = {
  PRIMARY_COLOR,
  createPanelEmbed,
  createSuccessEmbed,
  createInvalidCodeEmbed,
  createAlreadyRedeemedEmbed,
  createErrorEmbed,
  createNoPermissionEmbed,
};
