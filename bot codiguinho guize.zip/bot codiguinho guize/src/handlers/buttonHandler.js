/**
 * ============================================
 * Handler de Botões
 * ============================================
 * Processa cliques nos botões do bot.
 * Atualmente gerencia o botão de resgatar
 * codiguinho, abrindo o modal (pop-up).
 * ============================================
 */

const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
} = require("discord.js");

/**
 * Processa o clique no botão "🎁 RESGATAR CODIGUINHO".
 * Abre um modal (pop-up) para o jogador digitar o código.
 */
async function handleButton(interaction) {
  if (interaction.customId !== "redeem_codiguinho") return;

  // Cria o modal (pop-up)
  const modal = new ModalBuilder()
    .setCustomId("redeem_modal")
    .setTitle("Resgatar Codiguinho Guize City");

  // Campo de texto para digitar o codiguinho
  const codeInput = new TextInputBuilder()
    .setCustomId("code_input")
    .setLabel("Digite seu codiguinho")
    .setPlaceholder("Coloque seu codiguinho aqui...")
    .setStyle(TextInputStyle.Short)
    .setMinLength(1)
    .setMaxLength(50)
    .setRequired(true);

  // Adiciona o campo ao modal (cada ActionRow comporta um campo)
  const row = new ActionRowBuilder().addComponents(codeInput);
  modal.addComponents(row);

  await interaction.showModal(modal);
}

module.exports = { handleButton };
