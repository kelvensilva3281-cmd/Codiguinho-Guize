/**
 * ============================================
 * Handler de Modais (Pop-ups)
 * ============================================
 * Processa a confirmação do resgate de
 * codiguinhos. Executa todas as regras:
 *
 * 1. Verifica se o jogador já resgatou (banco)
 * 2. Valida se o código existe
 * 3. Entrega o cargo no Discord
 * 4. Salva o resgate no banco de dados
 * ============================================
 */

const config = require("../../config/config.json");
const { isValidCode, normalizeCode } = require("../utils/codes");
const { getRedemption, addRedemption } = require("../database");
const {
  createSuccessEmbed,
  createInvalidCodeEmbed,
  createAlreadyRedeemedEmbed,
  createErrorEmbed,
} = require("../utils/embeds");

/**
 * Processa a submissão do modal de resgate.
 */
async function handleModal(interaction) {
  if (interaction.customId !== "redeem_modal") return;

  const rawCode = interaction.fields.getTextInputValue("code_input");
  const code = normalizeCode(rawCode);
  const userId = interaction.user.id;
  const username = interaction.user.username;

  // ── REGRA 1 & 2: Verificar se o jogador já resgatou ──
  const existing = getRedemption(userId);
  if (existing) {
    const embed = createAlreadyRedeemedEmbed(existing.code);
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  // ── REGRA 5 & 7: Validar se o codiguinho existe ──
  if (!isValidCode(rawCode)) {
    const embed = createInvalidCodeEmbed();
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  // ── REGRA 3 & 4: Entregar o cargo ──
  try {
    const member = await interaction.guild.members.fetch(userId);
    const role = interaction.guild.roles.cache.get(config.roleId);

    if (!role) {
      const embed = createErrorEmbed(
        "❌ O cargo configurado não foi encontrado no servidor.\nContate um administrador."
      );
      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    // Verifica se o jogador já tem o cargo (segurança extra)
    if (member.roles.cache.has(config.roleId)) {
      // Já tem o cargo — apenas registra no banco e confirma
      addRedemption(userId, username, code, new Date().toISOString());
      const embed = createSuccessEmbed(code, username);
      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    // Adiciona o cargo ao jogador
    await member.roles.add(role);

    // ── REGRA 8: Salvar o resgate no banco de dados ──
    addRedemption(userId, username, code, new Date().toISOString());

    // ── REGRA 6: Confirmar o resgate ──
    const embed = createSuccessEmbed(code, username);
    await interaction.reply({ embeds: [embed], ephemeral: true });
  } catch (error) {
    console.error("Erro ao entregar cargo:", error);

    // Erro comum: o bot não tem permissão ou o cargo está acima do bot
    let message = "❌ Ocorreu um erro ao entregar o cargo. Tente novamente.";
    if (error.code === 50013) {
      message =
        "❌ O bot não tem permissão para gerenciar cargos.\n" +
        "Verifique se o bot tem a permissão **Gerenciar Cargos** e se o cargo está **abaixo** do cargo do bot.";
    }
    const embed = createErrorEmbed(message);
    await interaction.reply({ embeds: [embed], ephemeral: true }).catch(() => {});
  }
}

module.exports = { handleModal };
